# Assign 'Bob' to the name variable
name="Bob"

# Print the value of the name variable
print(name)

# Assign 7 to the number variable
number=7

# Print the value of the number variable
print(number)