# Assign 2 to the apple_price variable
apple_price =2


# Assign 5 to the count variable
count=5

# Assign the result of apple_price * the count variable to the total_price variable
total_price =apple_price*count

# By using the count variable, print 'You will buy .. apples'
print("You will buy "+str(count)+" apples")

# By using the total_price variable, print 'The total price is .. dollars'
print("The total price is "+str(total_price)+" dollars")

