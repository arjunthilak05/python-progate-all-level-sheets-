apple_price = 2
apple_count = 8

# Assign the result of apple_price * apple_count to the total_price variable
total_price =apple_price*apple_count


# Print the value of the total_price variable
print(total_price)
