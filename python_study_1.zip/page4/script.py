# Print the result of 9 / 2
print(9/2)

# Print the result of 7 * 5
print(7*5)

# Print the remainder of 5 divided by 2 using %
print(5%2)